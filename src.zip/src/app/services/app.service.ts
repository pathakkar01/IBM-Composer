import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable()
export class AppService {
  conga_auth_endpoint =
    'https:services.congamerge.com/api/v1/auth/connect/token';

  salesforce_login_endpoint =
    'https:login.salesforce.com/services/oauth2/token';

  proxy_server_endPoint =
    'https:congalabapi.azurewebsites.net/api/CLMAuth/ExecuteMethod';
  proxy_server_endpoint_urlencoded =
    'https:congalabapi.azurewebsites.net/api/CLMAuth/ExecuteMethodFormURLEncode';

  conga_merge_endpoint = 'https:services.congamerge.com/api/v1/ingress/Merge';

  conga_merge_masterId = 'a0C7Q0000022FjlUAE';

  conga_merge_templateId = 'aA27Q000000Y24kSAC';

  conga_merge_UL =
    'https:ibmv2220.my.salesforce.com/services/Soap/u/50.0/00D7Q000008KjxV';

  JSONObjComposerReq = {
    json: {
      grant_type: 'client_credentials',
      scope: 'doc-gen.composer',
      client_id: '81532c73-b1af-4c85-8e9b-acf2ae36e962',
      client_secret: '0_Hd8_9?687uR6fnRWNqZw2-H',
    },
    methodType: 'POST',
    uri: this.conga_auth_endpoint,
  };

  JSONObjSFDCReq = {
    json: {},
    methodType: 'POST',
    uri: 'https:login.salesforce.com/services/oauth2/token?grant_type=password&client_id=3MVG9t0sl2P.pByqWU7HYKT7TTZ4CvqWRf4hIKs4PmydE8Sl_4nQs5CNOlr5uHxJa8920IY3zUDGyrqIKm0pO&client_secret=0C04FA0CA07AF5C98A0ED9AD40EB82DEDF4071811C0301070A8EC34244AA3CDC&username=ibm-v22.2.0@congademo.com&password=conga2022&redirect_uri=https:ibmv2220.lightning.force.com/',
  };

  constructor(private http: HttpClient) {}
  getComposerToken(): Observable<any> {
    let headers = new HttpHeaders({
      'Content-Type': 'application/json',
    });
    let options = { headers: headers };

    return this.http.post(
      this.proxy_server_endpoint_urlencoded,
      this.JSONObjComposerReq,
      options
    );
  }

  getSalesforceToken(): Observable<any> {
    let headers = new HttpHeaders({
      'Content-Type': 'application/json',
    });
    let options = { headers: headers };

    return this.http.post(
      this.proxy_server_endPoint,
      this.JSONObjSFDCReq,
      options
    );
  }

  generateDocViaMergeAPI(
    accessToken: String,
    sfToken: String,
    projectName: string,
    clientLegalName: string,
    masterObjId: string,
    validUntilDate: string,
    requestedBy: string,
    pcrNumber: string
  ): Observable<any> {
    let headers = new HttpHeaders({
      'Content-Type': 'application/json',
    });
    let options = { headers: headers };

    var JSONObjSFDCMerReq = {
      json: {
        SalesforceRequest: {
          SessionId: sfToken,
          TemplateId: this.conga_merge_templateId,
          MasterId: this.conga_merge_masterId,
          ServerUrl: this.conga_merge_UL,
        },
        LegacyOptions: {
          sc0: '1',
          sc1: 'SalesforceFile',
          DefaultPDF: '1',
          DS7: '11',
        },
        jsonData: {
          projectName: projectName,
          requestedBy: requestedBy,
          pcrNumber: pcrNumber,
          validUntilDate: validUntilDate,
          clientLegalName: clientLegalName,
        },
      },
      methodType: 'POST',
      uri: this.conga_merge_endpoint,
    };

    return this.http.post(
      this.conga_merge_endpoint,
      JSONObjSFDCMerReq,
      options
    );
  }
}
